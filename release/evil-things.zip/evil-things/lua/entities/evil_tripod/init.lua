AddCSLuaFile("shared.lua")
AddCSLuaFile("cl_init.lua")
include("shared.lua")

function ENT:DoSpecialPower(target)
    if not IsValid(target) then return end
    local start = self:GetPos() + Vector(0,0,135)
    local finish = target:WorldSpaceCenter()
    -- Unreliable tracking: most pulses drift off target, some lock on accurately.
    if math.random() > 0.4 then finish = finish + VectorRand()*math.random(90,220) end
    local tr = util.TraceLine({start=start, endpos=finish, filter=self, mask=MASK_SHOT})
    local hitPos = tr.HitPos
    local ed = EffectData(); ed:SetStart(start); ed:SetOrigin(hitPos); ed:SetEntity(self); ed:SetScale(2)
    util.Effect("ToolTracer", ed, true, true)
    if tr.Entity == target then
        local dmg = DamageInfo(); dmg:SetDamage(34); dmg:SetAttacker(self); dmg:SetInflictor(self); dmg:SetDamageType(DMG_DISSOLVE)
        target:TakeDamageInfo(dmg)
    end
end

function ENT:DoAttackPower(ply)
    if not IsValid(ply) or self.Capturing then return end
    self.Capturing = true
    self.CaptureReleased=false
    self.CaptureVictim=ply
    self:SetNW2Entity("EvilTripodCageTarget", ply)
    ply:SetNW2Bool("EvilTripodCaptured", true)
    if Evil and Evil.Claim then Evil.Claim(ply, self) end
    if Evil and Evil.Freeze then Evil.Freeze(ply) else ply:Freeze(true) end
    -- Captive hangs in a cage tucked under and behind the head, between the rear limbs.
    local cagePos = self:GetPos() - self:GetForward()*28 + Vector(0,0,74)
    ply:SetPos(cagePos)
    ply:SetEyeAngles((self:GetPos() - ply:GetPos()):Angle())

    local settled=false
    local release
    self.EscapeHookName="EvilTripodEscape_"..self:EntIndex()
    local presses=0
    hook.Add("KeyPress",self.EscapeHookName,function(who,key)
        if who~=ply or key~=IN_JUMP or settled then return end
        presses=presses+1
        if presses>=8 then settled=true; release(ply,false) end
    end)
    ply:ChatPrint("Ты в клетке! Нажми ПРЫЖОК 8 раз, чтобы вырваться и отлететь.")

    release=function(victim, kill)
        if not IsValid(self) or self.CaptureReleased then return end
        self.CaptureReleased=true
        hook.Remove("KeyPress",self.EscapeHookName)
        timer.Remove("EvilTripodCage_"..self:EntIndex())
        if IsValid(victim) then
            victim:SetNW2Bool("EvilTripodCaptured", false)
            if Evil and Evil.Thaw then Evil.Thaw(victim) else victim:Freeze(false) end
            if Evil and Evil.Unclaim then Evil.Unclaim(victim, self) end
            if kill and victim:Alive() then
                local d = DamageInfo(); d:SetDamage(9999); d:SetAttacker(self); d:SetInflictor(self); d:SetDamageType(DMG_DISSOLVE)
                victim:TakeDamageInfo(d)
            end
        end
        if IsValid(victim) and Evil and Evil.StopMash then Evil.StopMash(victim) end
        if not kill and IsValid(victim) and EvilThings and EvilThings.ThrowFree then EvilThings.ThrowFree(victim,self,560,310) end
        self:SetNW2Entity("EvilTripodCageTarget", NULL)
        self.Capturing = false
        self.CaptureVictim=nil
    end


    if Evil and Evil.Mash then
        Evil.Mash(ply, self, {
            key = IN_JUMP, gain = 0.14, decay = 0.12, time = 5, prompt = true,
            done = function(victim) if not settled then settled = true; release(victim, false) end end,
            fail = function(victim) if not settled then settled = true; release(victim, true) end end
        })
    end
    timer.Create("EvilTripodCage_" .. self:EntIndex(), 5.1, 1, function()
        if not settled then settled = true; release(ply, true) end
    end)
end

function ENT:OnRemove()
    timer.Remove("EvilTripodCage_" .. self:EntIndex())
    if self.EscapeHookName then hook.Remove("KeyPress",self.EscapeHookName) end
    local victim = self:GetNW2Entity("EvilTripodCageTarget")
    if IsValid(victim) then
        if Evil and Evil.StopMash then Evil.StopMash(victim) end
        victim:SetNW2Bool("EvilTripodCaptured", false)
        if Evil and Evil.Thaw then Evil.Thaw(victim) else victim:Freeze(false) end
        if Evil and Evil.Unclaim then Evil.Unclaim(victim, self) end
    end
    if Evil and Evil.Absent then Evil.Absent(self) end
end
